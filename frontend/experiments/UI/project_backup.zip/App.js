import React, { useState } from "react";
import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { createDrawerNavigator } from "react-navigation-drawer";
import AppLoading from "expo-app-loading";

import * as Font from "expo-font";
import AccountScreen from "./src/screens/AccountScreen";
import CollegeRecommend from "./src/screens/CollegeRecommend";
import CollegeScreen from "./src/screens/CollegeScreen";
import CollegeSurvey from "./src/screens/CollegeSurvey";
import LoginScreen from "./src/screens/LoginScreen";
import MajorRecommend from "./src/screens/MajorRecommend";
import MajorScreen from "./src/screens/MajorScreen";
import MajorSurvey from "./src/screens/MajorSurvey";
import OptionalProfileDetailGroup from "./src/screens/OptionalProfileDetailGroup";
import ProfileDetail from "./src/screens/ProfileDetail";
import ScholarshipRecommend from "./src/screens/ScholarshipRecommend";
import ScholarshipScreen from "./src/screens/ScholarshipScreen";
import Untitled from "./src/screens/Untitled";
import AccountScreen1 from "./src/screens/AccountScreen1";

const DrawerNavigation = createDrawerNavigator({
  AccountScreen: AccountScreen,
  CollegeRecommend: CollegeRecommend,
  CollegeScreen: CollegeScreen,
  CollegeSurvey: CollegeSurvey,
  LoginScreen: LoginScreen,
  MajorRecommend: MajorRecommend,
  MajorScreen: MajorScreen,
  MajorSurvey: MajorSurvey,
  OptionalProfileDetailGroup: OptionalProfileDetailGroup,
  ProfileDetail: ProfileDetail,
  ScholarshipRecommend: ScholarshipRecommend,
  ScholarshipScreen: ScholarshipScreen,
  Untitled: Untitled,
  AccountScreen1: AccountScreen1
});

const StackNavigation = createStackNavigator(
  {
    DrawerNavigation: {
      screen: DrawerNavigation
    },
    AccountScreen: AccountScreen,
    CollegeRecommend: CollegeRecommend,
    CollegeScreen: CollegeScreen,
    CollegeSurvey: CollegeSurvey,
    LoginScreen: LoginScreen,
    MajorRecommend: MajorRecommend,
    MajorScreen: MajorScreen,
    MajorSurvey: MajorSurvey,
    OptionalProfileDetailGroup: OptionalProfileDetailGroup,
    ProfileDetail: ProfileDetail,
    ScholarshipRecommend: ScholarshipRecommend,
    ScholarshipScreen: ScholarshipScreen,
    Untitled: Untitled,
    AccountScreen1: AccountScreen1
  },
  {
    headerMode: "none"
  }
);

const AppContainer = createAppContainer(StackNavigation);

function App() {
  const [isLoadingComplete, setLoadingComplete] = useState(false);
  if (!isLoadingComplete) {
    return (
      <AppLoading
        startAsync={loadResourcesAsync}
        onError={handleLoadingError}
        onFinish={() => handleFinishLoading(setLoadingComplete)}
      />
    );
  } else {
    return isLoadingComplete ? <AppContainer /> : <AppLoading />;
  }
}
async function loadResourcesAsync() {
  await Promise.all([
    Font.loadAsync({
      "roboto-700": require("./src/assets/fonts/roboto-700.ttf"),
      "lemonada-700": require("./src/assets/fonts/lemonada-700.ttf"),
      "roboto-regular": require("./src/assets/fonts/roboto-regular.ttf"),
      "arial-regular": require("./src/assets/fonts/arial-regular.ttf")
    })
  ]);
}
function handleLoadingError(error) {
  console.warn(error);
}

function handleFinishLoading(setLoadingComplete) {
  setLoadingComplete(true);
}

export default App;
