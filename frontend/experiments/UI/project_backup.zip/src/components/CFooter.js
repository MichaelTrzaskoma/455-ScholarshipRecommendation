import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import MaterialBasicFooter from "./MaterialBasicFooter";

function CFooter(props) {
  return (
    <View style={[styles.container, props.style]}>
      <MaterialBasicFooter
        style={styles.materialBasicFooter}
      ></MaterialBasicFooter>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {},
  materialBasicFooter: {
    width: 375,
    height: 56
  }
});

export default CFooter;
