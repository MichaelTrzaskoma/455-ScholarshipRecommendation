import React, { Component } from "react";
import { StyleSheet, TouchableOpacity } from "react-native";

function SignInButton(props) {
  return (
    <TouchableOpacity
      style={[styles.container, props.style]}
    ></TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "transparent",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    borderRadius: 5,
    opacity: 0.23
  }
});

export default SignInButton;
