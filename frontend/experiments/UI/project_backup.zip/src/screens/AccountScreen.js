import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  Text,
  TouchableOpacity
} from "react-native";
import MaterialBasicFooter6 from "../components/MaterialBasicFooter6";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import MaterialIconsIcon from "react-native-vector-icons/MaterialIcons";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";

function AccountScreen(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <MaterialBasicFooter6
        style={styles.materialBasicFooter1}
      ></MaterialBasicFooter6>
      <View style={styles.userInfoContainer}>
        <View style={styles.icon1Row}>
          <MaterialCommunityIconsIcon
            name="account-outline"
            style={styles.icon1}
          ></MaterialCommunityIconsIcon>
          <View style={styles.nameColumn}>
            <Text style={styles.name}>Name</Text>
            <Text style={styles.email}>Email :</Text>
          </View>
          <View style={styles.userNameTextInputColumn}>
            <Text style={styles.userNameTextInput}></Text>
            <Text style={styles.userEmailTextInput}></Text>
          </View>
        </View>
      </View>
      <View style={styles.allButtonsGroup}>
        <View style={styles.addProfileDetailGroup}>
          <TouchableOpacity style={styles.addProfileButton}>
            <View style={styles.icon7Row}>
              <MaterialIconsIcon
                name="playlist-add"
                style={styles.icon7}
              ></MaterialIconsIcon>
              <Text style={styles.addProfileDetail2}>Add Profile Detail</Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.takeMajorQuizGroup}>
          <TouchableOpacity style={styles.takeMajorQuizButton}>
            <View style={styles.icon2Row}>
              <MaterialIconsIcon
                name="playlist-add"
                style={styles.icon2}
              ></MaterialIconsIcon>
              <Text style={styles.takeMajorQuiz}>Take Major Quiz</Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.addCollegePreferencesGroup}>
          <TouchableOpacity style={styles.addCollegeButton}>
            <View style={styles.icon6Row}>
              <MaterialIconsIcon
                name="playlist-add"
                style={styles.icon6}
              ></MaterialIconsIcon>
              <Text style={styles.collegePreferences}>
                Add College Preferences
              </Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.bookmarksGroup}>
          <TouchableOpacity style={styles.bookMarksButton}>
            <View style={styles.icon3Row}>
              <MaterialIconsIcon
                name="vpn-key"
                style={styles.icon3}
              ></MaterialIconsIcon>
              <Text style={styles.bookmarks}>Bookmarks</Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.signoutGroup}>
          <TouchableOpacity style={styles.signOutBotton}>
            <View style={styles.icon5Row}>
              <FontAwesomeIcon
                name="sign-out"
                style={styles.icon5}
              ></FontAwesomeIcon>
              <Text style={styles.signOut}>Sign-Out</Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  materialBasicFooter1: {
    height: 56,
    width: 360,
    marginTop: 684
  },
  userInfoContainer: {
    height: 179,
    backgroundColor: "#e6e6e6",
    marginTop: -648
  },
  icon1: {
    color: "rgba(155,155,155,1)",
    fontSize: 140
  },
  name: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 20
  },
  email: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginTop: 21
  },
  nameColumn: {
    width: 53,
    marginTop: 44,
    marginBottom: 46
  },
  userNameTextInput: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 31,
    width: 153,
    fontSize: 16,
    marginLeft: 12
  },
  userEmailTextInput: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 29,
    width: 153,
    fontSize: 16,
    marginTop: 12
  },
  userNameTextInputColumn: {
    width: 165,
    marginTop: 46,
    marginBottom: 36
  },
  icon1Row: {
    height: 154,
    flexDirection: "row",
    marginLeft: -12,
    marginRight: 14
  },
  allButtonsGroup: {
    height: 296,
    marginTop: 59
  },
  addProfileDetailGroup: {
    width: 360,
    height: 50
  },
  addProfileButton: {
    width: 360,
    height: 50,
    backgroundColor: "#e6e6e6",
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    flexDirection: "row"
  },
  icon7: {
    color: "rgba(107,164,39,1)",
    fontSize: 35
  },
  addProfileDetail2: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 27,
    marginTop: 10
  },
  icon7Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 155,
    marginLeft: 20,
    marginTop: 10
  },
  takeMajorQuizGroup: {
    width: 362,
    height: 53,
    marginTop: 9,
    marginLeft: 1
  },
  takeMajorQuizButton: {
    width: 360,
    height: 50,
    backgroundColor: "#e6e6e6",
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    flexDirection: "row"
  },
  icon2: {
    color: "rgba(107,164,39,1)",
    fontSize: 35
  },
  takeMajorQuiz: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 23,
    marginTop: 10
  },
  icon2Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 167,
    marginLeft: 21,
    marginTop: 8
  },
  addCollegePreferencesGroup: {
    width: 360,
    height: 57,
    marginTop: 7
  },
  addCollegeButton: {
    width: 360,
    height: 50,
    backgroundColor: "#e6e6e6",
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    flexDirection: "row"
  },
  icon6: {
    color: "rgba(107,164,39,1)",
    fontSize: 35
  },
  collegePreferences: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 25,
    marginTop: 9
  },
  icon6Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 104,
    marginLeft: 21,
    marginTop: 10
  },
  bookmarksGroup: {
    width: 361,
    height: 55,
    marginTop: 4,
    marginLeft: 1
  },
  bookMarksButton: {
    width: 360,
    height: 50,
    backgroundColor: "#e6e6e6",
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    flexDirection: "row"
  },
  icon3: {
    color: "rgba(234,159,19,1)",
    fontSize: 35
  },
  bookmarks: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 26,
    marginTop: 10
  },
  icon3Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 198,
    marginLeft: 20,
    marginTop: 8
  },
  signoutGroup: {
    width: 360,
    height: 56,
    marginTop: 5
  },
  signOutBotton: {
    width: 360,
    height: 50,
    backgroundColor: "#e6e6e6",
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    flexDirection: "row"
  },
  icon5: {
    color: "rgba(236,78,96,1)",
    fontSize: 35
  },
  signOut: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 28,
    marginTop: 9
  },
  icon5Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 217,
    marginLeft: 22,
    marginTop: 10
  }
});

export default AccountScreen;
