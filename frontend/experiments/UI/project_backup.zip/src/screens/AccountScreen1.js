import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import MaterialIconsIcon from "react-native-vector-icons/MaterialIcons";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";

function AccountScreen1(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.content_container}>
        <View style={styles.usrInfoContainer}>
          <View style={styles.usrIconRow}>
            <MaterialCommunityIconsIcon
              name="account-outline"
              style={styles.usrIcon}
            ></MaterialCommunityIconsIcon>
            <View style={styles.nameTxtColumn}>
              <Text style={styles.nameTxt}>Name:</Text>
              <Text style={styles.emailTxt}>Email:</Text>
            </View>
            <View style={styles.namePlaceHolderColumn}>
              <Text style={styles.namePlaceHolder}>Name Place Holder</Text>
              <Text style={styles.usrEmailTxt_display}>Email Place Holder</Text>
            </View>
          </View>
        </View>
        <View style={styles.accBtnGrp}>
          <View style={styles.addProfileDetailBtn}>
            <View style={styles.addProfileDetailIconRow}>
              <MaterialIconsIcon
                name="playlist-add"
                style={styles.addProfileDetailIcon}
              ></MaterialIconsIcon>
              <Text style={styles.addProfileDetailTxt}>Add Profile Detail</Text>
            </View>
          </View>
          <View style={styles.bookmarksBtn}>
            <View style={styles.bookmarksIconRow}>
              <MaterialIconsIcon
                name="vpn-key"
                style={styles.bookmarksIcon}
              ></MaterialIconsIcon>
              <Text style={styles.bookmarksTxt}>Bookmarks</Text>
            </View>
          </View>
          <View style={styles.signOutBtn}>
            <View style={styles.signOutIconRow}>
              <FontAwesomeIcon
                name="sign-out"
                style={styles.signOutIcon}
              ></FontAwesomeIcon>
              <Text style={styles.signOutTxt}>Sign-Out</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  content_container: {
    flex: 1
  },
  usrInfoContainer: {
    height: 113,
    backgroundColor: "#e6e6e6",
    marginTop: 51
  },
  usrIcon: {
    color: "rgba(155,155,155,1)",
    fontSize: 80
  },
  nameTxt: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16
  },
  emailTxt: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginTop: 11
  },
  nameTxtColumn: {
    width: 47,
    marginLeft: 18,
    marginTop: 17,
    marginBottom: 19
  },
  namePlaceHolder: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 20,
    width: 153,
    fontSize: 16,
    marginLeft: 2
  },
  usrEmailTxt_display: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 20,
    width: 153,
    fontSize: 16,
    marginTop: 10
  },
  namePlaceHolderColumn: {
    width: 155,
    marginLeft: 7,
    marginTop: 17,
    marginBottom: 20
  },
  usrIconRow: {
    height: 87,
    flexDirection: "row",
    marginTop: 13,
    marginLeft: 15,
    marginRight: 38
  },
  accBtnGrp: {
    height: 296,
    marginTop: 222
  },
  addProfileDetailBtn: {
    height: 50,
    backgroundColor: "rgba(230, 230, 230,1)",
    flexDirection: "row"
  },
  addProfileDetailIcon: {
    color: "rgba(107,164,39,1)",
    fontSize: 35
  },
  addProfileDetailTxt: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 25,
    marginTop: 8
  },
  addProfileDetailIconRow: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 157,
    marginLeft: 20,
    marginTop: 8
  },
  bookmarksBtn: {
    height: 50,
    backgroundColor: "rgba(230, 230, 230,1)",
    flexDirection: "row",
    marginTop: 14
  },
  bookmarksIcon: {
    color: "rgba(234,159,19,1)",
    fontSize: 35
  },
  bookmarksTxt: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 25,
    marginTop: 8
  },
  bookmarksIconRow: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 199,
    marginLeft: 20,
    marginTop: 8
  },
  signOutBtn: {
    height: 50,
    backgroundColor: "rgba(230, 230, 230,1)",
    flexDirection: "row",
    marginTop: 59
  },
  signOutIcon: {
    color: "rgba(236,78,96,1)",
    fontSize: 35
  },
  signOutTxt: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 16,
    marginLeft: 26,
    marginTop: 8
  },
  signOutIconRow: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 219,
    marginLeft: 22,
    marginTop: 8
  }
});

export default AccountScreen1;
