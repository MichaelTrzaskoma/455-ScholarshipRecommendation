import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";

function CollegeRecommend(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.collegeInfoGroup1}>
        <View style={styles.collegeRect1}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>Name:</Text>
            <Text style={styles.nameTextField}></Text>
          </View>
          <View style={styles.locationRow}>
            <Text style={styles.location}>Location:</Text>
            <Text style={styles.locationTextField}></Text>
          </View>
          <View style={styles.gpaRangeRow}>
            <Text style={styles.gpaRange}>GPA Range:</Text>
            <Text style={styles.gPATextField}></Text>
          </View>
          <View style={styles.satRangeRow}>
            <Text style={styles.satRange}>SAT Range:</Text>
            <Text style={styles.sATTextField}></Text>
          </View>
          <View style={styles.inStateTuitionRow}>
            <Text style={styles.inStateTuition}>In-state Tuition:</Text>
            <Text style={styles.iSTuitionTextField}></Text>
          </View>
          <View style={styles.oOSTuitionRow}>
            <Text style={styles.oOSTuition}>Out of State Tuition:</Text>
            <Text style={styles.oOSTuitionTextField}></Text>
          </View>
          <View style={styles.medianEarningRow}>
            <Text style={styles.medianEarning}>
              Median earnings six {"\n"}years after graduation:
            </Text>
            <Text style={styles.medianEarningTextField}></Text>
          </View>
        </View>
      </View>
      <View style={styles.collegeInfoGroup2}>
        <View style={styles.collegeRect2}>
          <Text style={styles.applyLink}>Apply Link:</Text>
          <Text style={styles.applyLinkTextField}></Text>
          <Text style={styles.description}>Description:</Text>
          <Text style={styles.descriptionTextField}></Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e8e9e7"
  },
  collegeInfoGroup1: {
    width: 318,
    height: 232,
    justifyContent: "center",
    marginTop: 38,
    marginLeft: 21
  },
  collegeRect1: {
    width: 318,
    height: 232,
    backgroundColor: "#fefffd",
    alignSelf: "center"
  },
  name: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16
  },
  nameTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 24,
    width: 234,
    marginLeft: 10,
    marginTop: 3
  },
  nameRow: {
    height: 27,
    flexDirection: "row",
    marginTop: 9,
    marginLeft: 18,
    marginRight: 9
  },
  location: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  locationTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 23,
    width: 210,
    marginLeft: 10,
    marginTop: 1
  },
  locationRow: {
    height: 24,
    flexDirection: "row",
    marginTop: 1,
    marginLeft: 16,
    marginRight: 19
  },
  gpaRange: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  gPATextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 23,
    width: 199,
    marginLeft: 7,
    marginTop: 1
  },
  gpaRangeRow: {
    height: 24,
    flexDirection: "row",
    marginTop: 5,
    marginLeft: 16,
    marginRight: 16
  },
  satRange: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  sATTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 23,
    width: 199,
    marginLeft: 8,
    marginTop: 2
  },
  satRangeRow: {
    height: 25,
    flexDirection: "row",
    marginTop: 3,
    marginLeft: 15,
    marginRight: 18
  },
  inStateTuition: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  iSTuitionTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 23,
    width: 166,
    marginLeft: 8,
    marginTop: 2
  },
  inStateTuitionRow: {
    height: 25,
    flexDirection: "row",
    marginTop: 5,
    marginLeft: 15,
    marginRight: 22
  },
  oOSTuition: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  oOSTuitionTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 23,
    width: 143,
    marginLeft: 8,
    marginTop: 1
  },
  oOSTuitionRow: {
    height: 24,
    flexDirection: "row",
    marginTop: 5,
    marginLeft: 15,
    marginRight: 17
  },
  medianEarning: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  medianEarningTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 23,
    width: 133,
    marginLeft: 8,
    marginTop: 18
  },
  medianEarningRow: {
    height: 41,
    flexDirection: "row",
    marginLeft: 16,
    marginRight: 7
  },
  collegeInfoGroup2: {
    width: 318,
    height: 408,
    marginTop: 26,
    marginLeft: 21
  },
  collegeRect2: {
    width: 318,
    height: 408,
    backgroundColor: "#fefffd"
  },
  applyLink: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15,
    marginTop: 19,
    marginLeft: 18
  },
  applyLinkTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 59,
    width: 284,
    marginTop: 8,
    marginLeft: 15
  },
  description: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15,
    marginLeft: 18
  },
  descriptionTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 255,
    width: 281,
    marginTop: 5,
    marginLeft: 18
  }
});

export default CollegeRecommend;
