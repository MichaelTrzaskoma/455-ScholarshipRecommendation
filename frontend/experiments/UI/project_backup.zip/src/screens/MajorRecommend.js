import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";

function MajorRecommend(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.majorInfoGroup2}>
        <View style={styles.majorInfoRect2}>
          <View style={styles.additInfoStack}>
            <Text style={styles.additInfo}>Additional Information:</Text>
            <Text style={styles.additInfoTextField}></Text>
          </View>
          <Text style={styles.furtherResearch}>
            We recommend conducting further research on common required
            coursework in your chosen major!
          </Text>
        </View>
      </View>
      <View style={styles.majorInfoGroup1}>
        <View style={styles.majorInfoRect1}>
          <Text style={styles.closetMatch}>Closest Match for Major:</Text>
          <View style={styles.yourMatchStack}>
            <Text style={styles.yourMatch}>Your Match Displayed Here!</Text>
            <Text style={styles.majorMacthTextField}></Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e8e9e7"
  },
  majorInfoGroup2: {
    width: 318,
    height: 489,
    marginTop: 231,
    marginLeft: 21
  },
  majorInfoRect2: {
    width: 318,
    height: 489,
    backgroundColor: "#fefffd"
  },
  additInfo: {
    top: 0,
    left: 0,
    position: "absolute",
    fontFamily: "roboto-700",
    color: "rgba(0,0,0,1)",
    height: 37,
    width: 298,
    fontSize: 15
  },
  additInfoTextField: {
    top: 26,
    left: 0,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 307,
    width: 298
  },
  additInfoStack: {
    width: 298,
    height: 333,
    marginTop: 23,
    marginLeft: 10
  },
  furtherResearch: {
    fontFamily: "roboto-700",
    color: "rgba(0,0,0,1)",
    height: 64,
    width: 298,
    fontSize: 15,
    marginTop: 29,
    marginLeft: 10
  },
  majorInfoGroup1: {
    width: 318,
    height: 180,
    marginTop: -703,
    marginLeft: 21
  },
  majorInfoRect1: {
    width: 318,
    height: 180,
    backgroundColor: "#fefffd"
  },
  closetMatch: {
    fontFamily: "roboto-700",
    color: "#4a76ff",
    height: 37,
    width: 298,
    fontSize: 20,
    marginTop: 11,
    marginLeft: 10
  },
  yourMatch: {
    top: 0,
    left: 0,
    position: "absolute",
    fontFamily: "roboto-700",
    color: "rgba(0,0,0,1)",
    height: 37,
    width: 298,
    fontSize: 15
  },
  majorMacthTextField: {
    top: 26,
    left: 0,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 68,
    width: 298
  },
  yourMatchStack: {
    width: 298,
    height: 94,
    marginTop: 27,
    marginLeft: 10
  }
});

export default MajorRecommend;
