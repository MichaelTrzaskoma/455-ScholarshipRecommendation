import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text, ScrollView } from "react-native";
import CupertinoButtonInfo1 from "../components/CupertinoButtonInfo1";

function MajorSurvey(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.majorSurveyGroup1}>
        <View style={styles.majorSurveyRect1}>
          <Text style={styles.toFindYourMajor}>To Find your major:</Text>
          <Text style={styles.surveyDescription}>
            Please Answer the Following Questions to the best of your ability.
            Using an outcomes based approach, we will recommend a field or major
            of best fit. Remember to do your own followup research!
          </Text>
        </View>
      </View>
      <View style={styles.majorSurveyGroup2}>
        <View style={styles.majorSurveyRect2}>
          <ScrollView
            horizontal={false}
            contentContainerStyle={
              styles.majorSurveyRect2_contentContainerStyle
            }
          >
            <Text style={styles.majorSurveyQA1}>
              Which of the following is an amount of debt you are willing to
              incur or an acceptable cost for your education over four years?
            </Text>
            <Text style={styles.majorSurveyQA2}>
              What median salary range do you expect after graduation?
            </Text>
            <Text style={styles.majorSurveyQA3}>
              Which of the following rates of unemployment{"\n"}are you willing
              to risk in pursuing your field?
            </Text>
            <CupertinoButtonInfo1
              style={styles.submitButton}
            ></CupertinoButtonInfo1>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e8e9e7"
  },
  majorSurveyGroup1: {
    width: 318,
    height: 180,
    marginTop: 18,
    marginLeft: 21
  },
  majorSurveyRect1: {
    width: 318,
    height: 180,
    backgroundColor: "#fefffd"
  },
  toFindYourMajor: {
    fontFamily: "roboto-700",
    color: "#4a76ff",
    height: 37,
    width: 298,
    fontSize: 20,
    marginTop: 10,
    marginLeft: 10
  },
  surveyDescription: {
    fontFamily: "roboto-700",
    color: "rgba(0,0,0,1)",
    height: 100,
    width: 298,
    fontSize: 15,
    marginTop: 13,
    marginLeft: 9
  },
  majorSurveyGroup2: {
    width: 321,
    height: 508,
    marginTop: 18,
    marginLeft: 21
  },
  majorSurveyRect2: {
    width: 321,
    height: 508,
    backgroundColor: "#fefffd"
  },
  majorSurveyRect2_contentContainerStyle: {
    height: 508,
    width: 321
  },
  majorSurveyQA1: {
    fontFamily: "roboto-700",
    color: "rgba(0,0,0,1)",
    height: 62,
    width: 298,
    fontSize: 15,
    marginTop: 24,
    marginLeft: 10
  },
  majorSurveyQA2: {
    fontFamily: "roboto-700",
    color: "rgba(0,0,0,1)",
    height: 37,
    width: 298,
    fontSize: 15,
    marginTop: 73,
    marginLeft: 9
  },
  majorSurveyQA3: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15,
    marginTop: 134,
    marginLeft: 3
  },
  submitButton: {
    width: 300,
    height: 36,
    backgroundColor: "#4a76ff",
    marginTop: 92,
    marginLeft: 10
  }
});

export default MajorSurvey;
