import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text, TextInput } from "react-native";
import CupertinoButtonInfo1 from "../components/CupertinoButtonInfo1";

function OptionalProfileDetailGroup(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.group}>
        <View style={styles.optionalDetailRect}>
          <View style={styles.optionalUserInfoGroup}>
            <Text style={styles.optionalDetails}>Optional Details</Text>
            <Text style={styles.name}>Name</Text>
            <TextInput
              placeholder="Major here"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.nameTextField}
            ></TextInput>
            <Text style={styles.race}>Race</Text>
            <TextInput
              placeholder="Race here"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.raceTextField}
            ></TextInput>
            <Text style={styles.religion}>Religion</Text>
            <TextInput
              placeholder="Religion here"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.religionTextField}
            ></TextInput>
            <Text style={styles.disabilities}>Disabilities</Text>
            <TextInput
              placeholder="Diabilities here"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.disabilitiesTextField}
            ></TextInput>
            <Text style={styles.testScore}>Test Score</Text>
            <TextInput
              placeholder="SAT"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.testScoreTextField}
            ></TextInput>
            <Text style={styles.ethnicity}>Ethnicity</Text>
            <TextInput
              placeholder="Ethnicity here"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.ethnicityTextField}
            ></TextInput>
            <Text style={styles.residentialAddress}>Residential Address</Text>
            <View style={styles.rATextField1Stack}>
              <TextInput
                placeholder="Address Line 1"
                autoCorrect={false}
                keyboardAppearance="light"
                style={styles.rATextField1}
              ></TextInput>
              <TextInput
                placeholder="Address Line 2"
                autoCorrect={false}
                keyboardAppearance="light"
                style={styles.rATextField2}
              ></TextInput>
            </View>
          </View>
          <CupertinoButtonInfo1
            style={styles.submittButton}
          ></CupertinoButtonInfo1>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e6e6e6"
  },
  group: {
    width: 361,
    height: 682,
    marginTop: 38,
    marginLeft: -1
  },
  optionalDetailRect: {
    width: 361,
    height: 682,
    backgroundColor: "#fefffd"
  },
  optionalUserInfoGroup: {
    width: 149,
    height: 538,
    marginTop: 34,
    marginLeft: 13
  },
  optionalDetails: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 20
  },
  name: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginTop: 15
  },
  nameTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  race: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginTop: 22
  },
  raceTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  religion: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginTop: 23
  },
  religionTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  disabilities: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginTop: 25
  },
  disabilitiesTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  testScore: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginTop: 24
  },
  testScoreTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  ethnicity: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginTop: 24
  },
  ethnicityTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  residentialAddress: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginTop: 28
  },
  rATextField1: {
    top: 0,
    left: 0,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  rATextField2: {
    top: 23,
    left: 0,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  rATextField1Stack: {
    width: 149,
    height: 51
  },
  submittButton: {
    width: 300,
    height: 36,
    backgroundColor: "#4a76ff",
    marginTop: 42,
    marginLeft: 26
  }
});

export default OptionalProfileDetailGroup;
