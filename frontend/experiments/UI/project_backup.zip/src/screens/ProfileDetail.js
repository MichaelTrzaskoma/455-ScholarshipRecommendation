import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text, TextInput } from "react-native";
import MaterialButtonViolet from "../components/MaterialButtonViolet";

function ProfileDetail(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.profileDetailGroup}>
        <View style={styles.profileDetailRect}>
          <View style={styles.userInfoGroup}>
            <Text style={styles.gender}>Gender</Text>
            <TextInput
              placeholder="Male/Female"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.genderTextField}
            ></TextInput>
            <Text style={styles.dateOfBirth}>Date of Birth</Text>
            <TextInput
              placeholder="mm/dd/yyyy"
              autoCorrect={false}
              keyboardAppearance="light"
              dataDetector="calendarEvent"
              style={styles.dOBTextField}
            ></TextInput>
            <Text style={styles.zipCode}>Zip Code</Text>
            <TextInput
              placeholder="12345"
              autoCorrect={false}
              keyboardAppearance="light"
              dataDetector="none"
              style={styles.zCTextField}
            ></TextInput>
            <Text style={styles.gpa}>GPA:</Text>
            <TextInput
              placeholder="4.0"
              autoCorrect={false}
              keyboardAppearance="light"
              style={styles.gPATextField}
            ></TextInput>
          </View>
          <MaterialButtonViolet
            style={styles.nextButton}
          ></MaterialButtonViolet>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e6e6e6"
  },
  profileDetailGroup: {
    width: 361,
    height: 410,
    justifyContent: "center",
    marginTop: 62,
    marginLeft: -1
  },
  profileDetailRect: {
    width: 361,
    height: 410,
    backgroundColor: "#fefffd",
    marginLeft: 1
  },
  userInfoGroup: {
    width: 155,
    height: 256,
    marginTop: 41,
    marginLeft: 10
  },
  gender: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 20
  },
  genderTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  dateOfBirth: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 20,
    marginTop: 17
  },
  dOBTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  zipCode: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 20,
    marginTop: 15
  },
  zCTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16
  },
  gpa: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 20,
    marginTop: 16
  },
  gPATextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 28,
    width: 149,
    fontSize: 16,
    marginLeft: 3
  },
  nextButton: {
    height: 36,
    width: 300,
    backgroundColor: "#4a76ff",
    marginTop: 42,
    marginLeft: 31
  }
});

export default ProfileDetail;
