import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";

function ScholarshipRecommend(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.scholarshipInfoGroup1}>
        <View style={styles.scholarshipInfoRect1}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>Name:</Text>
            <Text style={styles.nameTextField}></Text>
          </View>
          <View style={styles.amountRow}>
            <Text style={styles.amount}>Amount:</Text>
            <Text style={styles.amountTextField}></Text>
          </View>
          <View style={styles.deadlineRow}>
            <Text style={styles.deadline}>Deadline:</Text>
            <Text style={styles.deadlineTextField}></Text>
          </View>
          <View style={styles.awardsAvailableRow}>
            <Text style={styles.awardsAvailable}>Awards Available:</Text>
            <Text style={styles.awardTextField}></Text>
          </View>
        </View>
      </View>
      <View style={styles.scholarshipInfoGroup2}>
        <View style={styles.scholarshipInfoRect2}>
          <Text style={styles.applyLink}>Apply Link:</Text>
          <Text style={styles.applyLinkTextField}></Text>
          <Text style={styles.description}>Description:</Text>
          <Text style={styles.descriptionTextField}></Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e8e9e7"
  },
  scholarshipInfoGroup1: {
    width: 318,
    height: 232,
    marginTop: 39,
    marginLeft: 21
  },
  scholarshipInfoRect1: {
    width: 318,
    height: 232,
    backgroundColor: "#fefffd"
  },
  name: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16
  },
  nameTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 26,
    width: 201,
    marginLeft: 10
  },
  nameRow: {
    height: 26,
    flexDirection: "row",
    marginTop: 30,
    marginLeft: 18,
    marginRight: 42
  },
  amount: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  amountTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 26,
    width: 201,
    marginLeft: 6,
    marginTop: 1
  },
  amountRow: {
    height: 27,
    flexDirection: "row",
    marginTop: 33,
    marginLeft: 18,
    marginRight: 36
  },
  deadline: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  deadlineTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 26,
    width: 201,
    marginLeft: 8
  },
  deadlineRow: {
    height: 26,
    flexDirection: "row",
    marginTop: 30,
    marginLeft: 18,
    marginRight: 28
  },
  awardsAvailable: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  awardTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 26,
    width: 170,
    marginLeft: 6
  },
  awardsAvailableRow: {
    height: 26,
    flexDirection: "row",
    marginTop: 25,
    marginLeft: 18,
    marginRight: 4
  },
  scholarshipInfoGroup2: {
    width: 318,
    height: 408,
    marginTop: 26,
    marginLeft: 21
  },
  scholarshipInfoRect2: {
    width: 318,
    height: 408,
    backgroundColor: "#fefffd"
  },
  applyLink: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15,
    marginTop: 19,
    marginLeft: 18
  },
  applyLinkTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 60,
    width: 288,
    marginTop: 6,
    marginLeft: 15
  },
  description: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15,
    marginTop: 1,
    marginLeft: 18
  },
  descriptionTextField: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 265,
    width: 288,
    marginTop: 6,
    marginLeft: 15
  }
});

export default ScholarshipRecommend;
