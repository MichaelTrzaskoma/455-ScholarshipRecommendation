import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView
} from "react-native";
import MaterialCheckboxWithLabel15 from "../components/MaterialCheckboxWithLabel15";
import MaterialCheckboxWithLabel17 from "../components/MaterialCheckboxWithLabel17";
import MaterialCheckboxWithLabel18 from "../components/MaterialCheckboxWithLabel18";
import MaterialCheckboxWithLabel16 from "../components/MaterialCheckboxWithLabel16";
import MaterialCheckboxWithLabel19 from "../components/MaterialCheckboxWithLabel19";
import MaterialCheckboxWithLabel22 from "../components/MaterialCheckboxWithLabel22";
import MaterialCheckboxWithLabel20 from "../components/MaterialCheckboxWithLabel20";
import MaterialCheckboxWithLabel21 from "../components/MaterialCheckboxWithLabel21";
import MaterialCheckboxWithLabel from "../components/MaterialCheckboxWithLabel";
import MaterialCheckboxWithLabel1 from "../components/MaterialCheckboxWithLabel1";
import MaterialCheckboxWithLabel2 from "../components/MaterialCheckboxWithLabel2";
import MaterialCheckboxWithLabel3 from "../components/MaterialCheckboxWithLabel3";
import MaterialCheckboxWithLabel5 from "../components/MaterialCheckboxWithLabel5";
import MaterialCheckboxWithLabel8 from "../components/MaterialCheckboxWithLabel8";
import MaterialCheckboxWithLabel4 from "../components/MaterialCheckboxWithLabel4";
import MaterialCheckboxWithLabel6 from "../components/MaterialCheckboxWithLabel6";
import MaterialCheckboxWithLabel9 from "../components/MaterialCheckboxWithLabel9";
import MaterialCheckboxWithLabel10 from "../components/MaterialCheckboxWithLabel10";
import MaterialCheckboxWithLabel13 from "../components/MaterialCheckboxWithLabel13";
import MaterialCheckboxWithLabel14 from "../components/MaterialCheckboxWithLabel14";
import EntypoIcon from "react-native-vector-icons/Entypo";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <View style={styles.collegeLocation1}>
        <View style={styles.materialCheckboxWithLabel1Row}>
          <MaterialCheckboxWithLabel15
            style={styles.materialCheckboxWithLabel1}
          ></MaterialCheckboxWithLabel15>
          <View style={styles.materialCheckboxWithLabel3Stack}>
            <MaterialCheckboxWithLabel17
              style={styles.materialCheckboxWithLabel3}
            ></MaterialCheckboxWithLabel17>
            <MaterialCheckboxWithLabel18
              style={styles.materialCheckboxWithLabel4}
            ></MaterialCheckboxWithLabel18>
          </View>
        </View>
        <View style={styles.materialCheckboxWithLabel2Row}>
          <MaterialCheckboxWithLabel16
            style={styles.materialCheckboxWithLabel2}
          ></MaterialCheckboxWithLabel16>
          <MaterialCheckboxWithLabel19
            style={styles.materialCheckboxWithLabel5}
          ></MaterialCheckboxWithLabel19>
          <MaterialCheckboxWithLabel22
            style={styles.materialCheckboxWithLabel8}
          ></MaterialCheckboxWithLabel22>
        </View>
        <View style={styles.materialCheckboxWithLabel6Row}>
          <MaterialCheckboxWithLabel20
            style={styles.materialCheckboxWithLabel6}
          ></MaterialCheckboxWithLabel20>
          <MaterialCheckboxWithLabel21
            style={styles.materialCheckboxWithLabel7}
          ></MaterialCheckboxWithLabel21>
        </View>
      </View>
      <View style={styles.amountOfDebt1}>
        <View style={styles.materialCheckboxWithLabel9Row}>
          <MaterialCheckboxWithLabel
            style={styles.materialCheckboxWithLabel9}
          ></MaterialCheckboxWithLabel>
          <MaterialCheckboxWithLabel1
            style={styles.materialCheckboxWithLabel10}
          ></MaterialCheckboxWithLabel1>
          <MaterialCheckboxWithLabel2
            style={styles.materialCheckboxWithLabel11}
          ></MaterialCheckboxWithLabel2>
        </View>
      </View>
      <View style={styles.afterGraduation1}>
        <View style={styles.materialCheckboxWithLabel12Row}>
          <MaterialCheckboxWithLabel3
            style={styles.materialCheckboxWithLabel12}
          ></MaterialCheckboxWithLabel3>
          <MaterialCheckboxWithLabel5
            style={styles.materialCheckboxWithLabel14}
          ></MaterialCheckboxWithLabel5>
          <MaterialCheckboxWithLabel8
            style={styles.materialCheckboxWithLabel16}
          ></MaterialCheckboxWithLabel8>
        </View>
        <View style={styles.materialCheckboxWithLabel13Row}>
          <MaterialCheckboxWithLabel4
            style={styles.materialCheckboxWithLabel13}
          ></MaterialCheckboxWithLabel4>
          <MaterialCheckboxWithLabel6
            style={styles.materialCheckboxWithLabel15}
          ></MaterialCheckboxWithLabel6>
          <MaterialCheckboxWithLabel9
            style={styles.materialCheckboxWithLabel17}
          ></MaterialCheckboxWithLabel9>
        </View>
      </View>
      <View style={styles.unemployment1Stack}>
        <View style={styles.unemployment1}>
          <View style={styles.materialCheckboxWithLabel18Row}>
            <MaterialCheckboxWithLabel10
              style={styles.materialCheckboxWithLabel18}
            ></MaterialCheckboxWithLabel10>
            <MaterialCheckboxWithLabel13
              style={styles.materialCheckboxWithLabel19}
            ></MaterialCheckboxWithLabel13>
            <MaterialCheckboxWithLabel14
              style={styles.materialCheckboxWithLabel20}
            ></MaterialCheckboxWithLabel14>
          </View>
        </View>
        <View style={styles.recommendGroup1}>
          <Text style={styles.recommend2}>Recommend</Text>
          <View style={styles.customViewGroup1Row}>
            <TouchableOpacity style={styles.customViewGroup1}>
              <View style={styles.rect1}>
                <EntypoIcon
                  name="arrow-with-circle-right"
                  style={styles.icon1}
                ></EntypoIcon>
                <Text style={styles.customView2}>Custom View</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.recentViewGroup1}>
              <View style={styles.rect2}>
                <EntypoIcon
                  name="back-in-time"
                  style={styles.icon2}
                ></EntypoIcon>
                <Text style={styles.recentView2}>Recent{"\n"}View</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={styles.catagoryGroup1}>
        <Text style={styles.category1}>Category</Text>
        <View style={styles.scrollArea1}>
          <ScrollView
            horizontal={true}
            contentContainerStyle={styles.scrollArea1_contentContainerStyle}
          >
            <View style={styles.aHGroup1Row}>
              <TouchableOpacity style={styles.aHGroup1}>
                <View style={styles.rect3}>
                  <Text style={styles.artsAndHumanities1}>
                    Arts{"\n"}and{"\n"}Humanities
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sMtGroup1}>
                <View style={styles.rect4}>
                  <Text style={styles.artsAndHumanities2}>
                    Science,{"\n"}Math, and{"\n"}Technology
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity style={styles.buineGroup1}>
                <View style={styles.rect5}>
                  <Text style={styles.buiness1}>Buiness</Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button1}>
                <View style={styles.rect6}>
                  <EntypoIcon
                    name="arrow-with-circle-right"
                    style={styles.icon3}
                  ></EntypoIcon>
                  <Text style={styles.viewAll1}>View All</Text>
                </View>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  collegeLocation1: {
    width: 292,
    height: 128,
    marginTop: 48,
    marginLeft: 22
  },
  materialCheckboxWithLabel1: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel3: {
    height: 40,
    width: 96,
    position: "absolute",
    left: 84,
    top: 0
  },
  materialCheckboxWithLabel4: {
    height: 40,
    width: 90,
    position: "absolute",
    left: 0,
    top: 0
  },
  materialCheckboxWithLabel3Stack: {
    width: 180,
    height: 40,
    marginLeft: 7
  },
  materialCheckboxWithLabel1Row: {
    height: 40,
    flexDirection: "row",
    marginLeft: 15
  },
  materialCheckboxWithLabel2: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel5: {
    height: 40,
    width: 90,
    marginLeft: 16,
    marginTop: 1
  },
  materialCheckboxWithLabel8: {
    height: 40,
    width: 90,
    marginTop: 1
  },
  materialCheckboxWithLabel2Row: {
    height: 41,
    flexDirection: "row",
    marginTop: 7,
    marginRight: 6
  },
  materialCheckboxWithLabel6: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel7: {
    height: 40,
    width: 90,
    marginLeft: 8
  },
  materialCheckboxWithLabel6Row: {
    height: 40,
    flexDirection: "row",
    marginLeft: 15,
    marginRight: 89
  },
  amountOfDebt1: {
    width: 270,
    height: 40,
    flexDirection: "row",
    marginTop: 12,
    marginLeft: 33
  },
  materialCheckboxWithLabel9: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel10: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel11: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel9Row: {
    height: 40,
    flexDirection: "row",
    flex: 1
  },
  afterGraduation1: {
    width: 276,
    height: 80,
    marginLeft: 30
  },
  materialCheckboxWithLabel12: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel14: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel16: {
    height: 40,
    width: 90,
    marginLeft: 6
  },
  materialCheckboxWithLabel12Row: {
    height: 40,
    flexDirection: "row"
  },
  materialCheckboxWithLabel13: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel15: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel17: {
    height: 40,
    width: 75,
    marginLeft: 4
  },
  materialCheckboxWithLabel13Row: {
    height: 40,
    flexDirection: "row",
    marginRight: 17
  },
  unemployment1: {
    top: 0,
    left: 16,
    width: 308,
    height: 40,
    position: "absolute",
    flexDirection: "row"
  },
  materialCheckboxWithLabel18: {
    height: 40,
    width: 90
  },
  materialCheckboxWithLabel19: {
    height: 40,
    width: 105,
    marginLeft: 6
  },
  materialCheckboxWithLabel20: {
    height: 40,
    width: 107
  },
  materialCheckboxWithLabel18Row: {
    height: 40,
    flexDirection: "row",
    flex: 1
  },
  recommendGroup1: {
    top: 33,
    left: 0,
    height: 188,
    position: "absolute",
    right: 0
  },
  recommend2: {
    fontFamily: "lemonada-700",
    color: "#4a76ff",
    fontSize: 30,
    width: 216,
    height: 60
  },
  customViewGroup1: {
    width: 117,
    height: 104,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0
  },
  rect1: {
    width: 117,
    height: 104,
    backgroundColor: "rgba(230,230, 230,1)"
  },
  icon1: {
    color: "rgba(128,128,128,1)",
    fontSize: 52,
    height: 58,
    width: 52,
    marginTop: 6,
    marginLeft: 59
  },
  customView2: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 39,
    width: 79,
    fontSize: 16,
    marginLeft: 7
  },
  recentViewGroup1: {
    width: 117,
    height: 104,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    marginLeft: 53
  },
  rect2: {
    width: 117,
    height: 104,
    backgroundColor: "#E6E6E6"
  },
  icon2: {
    color: "rgba(128,128,128,1)",
    fontSize: 52,
    height: 58,
    width: 52,
    marginTop: 2,
    marginLeft: 58
  },
  recentView2: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 39,
    width: 79,
    fontSize: 16,
    marginTop: 5,
    marginLeft: 5
  },
  customViewGroup1Row: {
    height: 104,
    flexDirection: "row",
    marginTop: 24,
    marginLeft: 11,
    marginRight: 62
  },
  unemployment1Stack: {
    height: 221,
    marginLeft: 6,
    marginRight: -6
  },
  catagoryGroup1: {
    width: 360,
    height: 216,
    marginTop: 9,
    marginLeft: -4
  },
  category1: {
    fontFamily: "lemonada-700",
    color: "#4a76ff",
    height: 51,
    width: 229,
    fontSize: 30,
    marginLeft: 22
  },
  scrollArea1: {
    width: 360,
    height: 165,
    backgroundColor: "#ffffff"
  },
  scrollArea1_contentContainerStyle: {
    width: 540,
    height: 165,
    flexDirection: "row"
  },
  aHGroup1: {
    width: 117,
    height: 104,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0
  },
  rect3: {
    width: 117,
    height: 104,
    backgroundColor: "#E6E6E6"
  },
  artsAndHumanities1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 57,
    width: 93,
    fontSize: 16,
    marginTop: 23,
    marginLeft: 16
  },
  sMtGroup1: {
    width: 117,
    height: 104,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    marginLeft: 16
  },
  rect4: {
    width: 117,
    height: 104,
    backgroundColor: "#E6E6E6"
  },
  artsAndHumanities2: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 57,
    width: 93,
    fontSize: 16,
    marginTop: 23,
    marginLeft: 12
  },
  buineGroup1: {
    width: 117,
    height: 104,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    marginLeft: 19
  },
  rect5: {
    width: 117,
    height: 104,
    backgroundColor: "#E6E6E6"
  },
  buiness1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 57,
    width: 93,
    fontSize: 16,
    marginTop: 23,
    marginLeft: 12
  },
  button1: {
    width: 117,
    height: 104,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.16,
    shadowRadius: 0,
    marginLeft: 20
  },
  rect6: {
    width: 117,
    height: 104,
    backgroundColor: "#E6E6E6"
  },
  icon3: {
    color: "rgba(128,128,128,1)",
    fontSize: 52,
    height: 58,
    width: 52,
    marginTop: 15,
    marginLeft: 49
  },
  viewAll1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 23,
    width: 68,
    fontSize: 16,
    marginTop: 3,
    marginLeft: 8
  },
  aHGroup1Row: {
    height: 104,
    flexDirection: "row",
    flex: 1,
    marginRight: -180,
    marginLeft: 17,
    marginTop: 31
  }
});

export default Untitled;
